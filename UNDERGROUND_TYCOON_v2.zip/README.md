# UNDERGROUND TYCOON — Telegram Mini App starter

This is a playable mobile-first prototype plus a Node.js backend scaffold.

## Included
- Responsive five-tab game UI (Home, Shop, Inventory, Market, Profile)
- Coins, XP, 10 ranks, upgrades, passive income, random drops
- Daily quests/reward, achievements, prestige
- Player-to-player listings using virtual coins
- Referral code and referral-link UI
- Telegram WebApp SDK integration hook
- Backend scaffold for Telegram initData verification and server-authoritative player state
- PostgreSQL schema

## Run the playable prototype
Open `frontend/index.html` in a browser. Progress is saved in localStorage.
For Telegram, host the frontend on HTTPS and set the URL in BotFather.

## Run backend scaffold
1. Install Node.js 20+ and PostgreSQL.
2. `cd backend && npm install`
3. Copy `.env.example` to `.env`, fill `BOT_TOKEN`, `DATABASE_URL`, and `WEBAPP_URL`.
4. Run the SQL in `schema.sql`.
5. `npm run dev`

The frontend prototype currently uses localStorage. It is NOT yet wired to the backend endpoints.
Before public launch, connect every economy action to server endpoints and remove client-authoritative balances.

## Real-money purchases
For digital goods inside Telegram, use Telegram Stars (`XTR`) invoices. The backend includes a safe integration outline.
Do not accept card details in the Mini App. Do not promise cash withdrawals or cash-equivalent value for virtual items.
The player marketplace in this starter uses virtual coins only. Add real-money checkout only for clearly defined digital goods and follow Telegram's current payment rules.

## Production checklist
- HTTPS hosting and BotFather Mini App configuration
- Verify Telegram `initData` on every authenticated API request
- Server-authoritative balances, inventory, cooldowns and trades
- Idempotent payment webhook / successful_payment processing
- Rate limiting, audit logs, anti-bot/referral abuse checks
- Database transactions for purchases and marketplace transfers
- Privacy policy, terms, support contact and age-appropriate design
- Load/security testing and backups
